
import 'package:flutter/material.dart';
import '../widgets/crossword_grid.dart';

class CrosswordScreen extends StatelessWidget {
  const CrosswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('मराठी Crossword'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          const Text(
            'Daily Puzzle',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: CrosswordGrid(),
            ),
          ),
        ],
      ),
    );
  }
}
