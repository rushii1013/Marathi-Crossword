
import 'package:flutter/material.dart';
import 'features/crossword/screens/crossword_screen.dart';

void main() {
  runApp(const MarathiCrosswordApp());
}

class MarathiCrosswordApp extends StatelessWidget {
  const MarathiCrosswordApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Marathi Crossword',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepOrange,
      ),
      home: const CrosswordScreen(),
    );
  }
}
